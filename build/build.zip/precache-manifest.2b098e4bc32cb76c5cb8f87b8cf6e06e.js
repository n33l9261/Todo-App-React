self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0cd20f0220fc5c1596bffdbf671054e5",
    "url": "/todo/index.html"
  },
  {
    "revision": "7027fc2fb02696f7d137",
    "url": "/todo/static/css/main.ef75ab39.chunk.css"
  },
  {
    "revision": "d30dceb90f80704ddd39",
    "url": "/todo/static/js/2.c611a9ea.chunk.js"
  },
  {
    "revision": "7673ff7161c06d866a35ccc71abfab71",
    "url": "/todo/static/js/2.c611a9ea.chunk.js.LICENSE.txt"
  },
  {
    "revision": "7027fc2fb02696f7d137",
    "url": "/todo/static/js/main.2685f55e.chunk.js"
  },
  {
    "revision": "bdb94e8564ea2a8ad029",
    "url": "/todo/static/js/runtime-main.af8a041e.js"
  }
]);